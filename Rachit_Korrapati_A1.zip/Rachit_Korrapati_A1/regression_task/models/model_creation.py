# evaluate_models.py

import pandas as pd
import numpy as np
import pickle

# Load the processed dataset
df = pd.read_csv('processed_fuel_train.csv')

# Separate features (X) and target variable (y)
X = df.drop(['FUEL CONSUMPTION'], axis=1).values
y = df['FUEL CONSUMPTION'].values

# Add a bias term (intercept) to the feature matrix
X = np.c_[np.ones(X.shape[0]), X]

# Print number of features in X
print(f"Number of features in the evaluation dataset: {X.shape[1]}")

# Define the prediction function
def predict(X, theta):
    return np.dot(X, theta)

# Load and evaluate the models
def evaluate_models():
    models = ['model1.pkl', 'model2.pkl', 'model3.pkl']
    best_model = None
    lowest_cost = float('inf')

    for model in models:
        # Load the model parameters (theta)
        with open(model, 'rb') as f:
            theta = pickle.load(f)

        # Debugging: Check the shape of theta
        print(f"\nEvaluating {model}:")
        print(f"Shape of theta: {theta.shape}")

        # Check if the shapes align
        if len(theta) != X.shape[1]:
            print(f"Warning: The number of features in X ({X.shape[1]}) does not match the number of parameters in {model} ({len(theta)})")
            continue  # Skip this model

        # Calculate predictions
        predictions = predict(X, theta)

        # Calculate cost (Mean Squared Error)
        cost = (1 / (2 * len(y))) * np.sum((predictions - y) ** 2)  # Calculate Mean Squared Error

        print(f"{model} - Cost: {cost}")

        # Determine the best model based on cost
        if cost < lowest_cost:
            lowest_cost = cost
            best_model = model

    print(f"\nBest model: {best_model} with cost: {lowest_cost}")

if __name__ == "__main__":
    evaluate_models()
