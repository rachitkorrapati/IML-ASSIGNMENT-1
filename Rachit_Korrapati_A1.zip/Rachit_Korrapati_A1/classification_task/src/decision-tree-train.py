# src/train_model.py

import pickle
from data_preprocessing import load_data, preprocess_data, split_data
from decision_tree import DecisionTree

def train_and_save_model(X_train, y_train, model_name, max_depth):
    model = DecisionTree(max_depth=max_depth)
    model.fit(X_train.values, y_train.values)
    
    with open(f'../models/{model_name}.pkl', 'wb') as f:
        pickle.dump(model, f)
    
    return model

def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test.values)
    accuracy = sum(y_pred == y_test) / len(y_test)
    return accuracy

if __name__ == "__main__":
    # Load and preprocess data
    data = load_data('../data/training_data.csv')
    X, y = preprocess_data(data)
    X_train, X_test, y_train, y_test = split_data(X, y)
    
    # Train and evaluate models with different max_depths
    max_depths = [5, 10, None]
    
    best_model = None
    best_accuracy = 0
    
    for i, max_depth in enumerate(max_depths, 1):
        model_name = f'decision_tree_model{i}'
        model = train_and_save_model(X_train, y_train, model_name, max_depth)
        accuracy = evaluate_model(model, X_test, y_test)
        
        print(f"{model_name} (max_depth={max_depth}) - Accuracy: {accuracy:.4f}")
        
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_model = model
    
    # Save the best model as the final model
    with open('../models/decision_tree_model_final.pkl', 'wb') as f:
        pickle.dump(best_model, f)
    
    print(f"Best model saved as 'decision_tree_model_final.pkl'")
