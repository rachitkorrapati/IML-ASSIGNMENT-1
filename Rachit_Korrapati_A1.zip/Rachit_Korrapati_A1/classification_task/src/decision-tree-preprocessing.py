# src/data_preprocessing.py

import pandas as pd
import numpy as np

def load_data(file_path):
    """Load the dataset from a CSV file."""
    return pd.read_csv(file_path)

def preprocess_data(data):
    """Preprocess the data: handle missing values, encode categorical variables."""
    # Handle missing values
    data = data.dropna()
    
    # Encode categorical variables
    categorical_columns = ['type']
    for col in categorical_columns:
        data[col] = pd.Categorical(data[col]).codes
    
    # Separate features and target
    X = data.drop('isFraud', axis=1)
    y = data['isFraud']
    
    return X, y

def split_data(X, y, test_size=0.2, random_state=42):
    """Split the data into training and testing sets."""
    np.random.seed(random_state)
    indices = np.random.permutation(len(X))
    test_size = int(len(X) * test_size)
    test_indices = indices[:test_size]
    train_indices = indices[test_size:]
    
    X_train, X_test = X.iloc[train_indices], X.iloc[test_indices]
    y_train, y_test = y.iloc[train_indices], y.iloc[test_indices]
    
    return X_train, X_test, y_train, y_test

if __name__ == "__main__":
    # Test the preprocessing functions
    data = load_data('../data/training_data.csv')
    X, y = preprocess_data(data)
    X_train, X_test, y_train, y_test = split_data(X, y)
    print("Preprocessing complete. Shapes:")
    print(f"X_train: {X_train.shape}, y_train: {y_train.shape}")
    print(f"X_test: {X_test.shape}, y_test: {y_test.shape}")
