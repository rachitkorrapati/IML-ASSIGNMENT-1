# src/predict.py

import argparse
import numpy as np
import pandas as pd
import pickle
from data_preprocessing import preprocess_data

def load_model(model_path):
    with open(model_path, 'rb') as f:
        return pickle.load(f)

def predict(model, X):
    return model.predict(X.values)

def calculate_metrics(y_true, y_pred):
    accuracy = sum(y_pred == y_true) / len(y_true)
    precision = sum((y_pred == 1) & (y_true == 1)) / sum(y_pred == 1)
    recall = sum((y_pred == 1) & (y_true == 1)) / sum(y_true == 1)
    f1_score = 2 * (precision * recall) / (precision + recall)
    
    tn = sum((y_pred == 0) & (y_true == 0))
    fp = sum((y_pred == 1) & (y_true == 0))
    fn = sum((y_pred == 0) & (y_true == 1))
    tp = sum((y_pred == 1) & (y_true == 1))
    
    confusion_matrix = np.array([[tn, fp], [fn, tp]])
    
    return accuracy, precision, recall, f1_score, confusion_matrix

def save_metrics(metrics_path, accuracy, precision, recall, f1_score, confusion_matrix):
    with open(metrics_path, 'w') as f:
        f.write("Classification Metrics:\n")
        f.write(f"Accuracy: {accuracy:.2f}\n")
        f.write(f"Precision: {precision:.2f}\n")
        f.write(f"Recall: {recall:.2f}\n")
        f.write(f"F1-Score: {f1_score:.2f}\n")
        f.write(f"Confusion Matrix:\n{confusion_matrix}\n")

def save_predictions(predictions_path, y_pred):
    np.savetxt(predictions_path, y_pred, delimiter=',', fmt='%d')

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict using trained decision tree model")
    parser.add_argument("--model_path", required=True, help="Path to the saved model file")
    parser.add_argument("--data_path", required=True, help="Path to the data CSV file")
    parser.add_argument("--metrics_output_path", required=True, help="Path to save metrics")
    parser.add_argument("--predictions_output_path", required=True, help="Path to save predictions")
    args = parser.parse_args()

    # Load data and model
    data = pd.read_csv(args.data_path)
    X, y_true = preprocess_data(data)
    model = load_model(args.model_path)

    # Make predictions
    y_pred = predict(model, X)

    # Calculate metrics
    accuracy, precision, recall, f1_score, confusion_matrix = calculate_metrics(y_true, y_pred)

    # Save metrics and predictions
    save_metrics(args.metrics_output_path, accuracy, precision, recall, f1_score, confusion_matrix)
    save_predictions(args.predictions_output_path, y_pred)

    print("Prediction complete. Metrics and predictions saved.")
